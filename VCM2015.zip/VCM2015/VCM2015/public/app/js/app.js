var app = angular.module('vcmApp', ['ui.router']);

app.config(function($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('/search');

  $stateProvider
    .state('search', {
      url: '/search',
      templateUrl: '/app/views/search.html',
      controller: 'SearchCtrl'
    })
    .state('runner', {
      url: '/runner?id&editMode',
      templateUrl: '/app/views/runner.html',
      controller: 'RunnerCtrl'
    });
});

app.factory('api', function($http) {
  var runnerApi = {};

  runnerApi.getRunners = function(query) {
    return $http.get('/api/runners?q=' + query);
  };

  return runnerApi;

});

app.controller('SearchCtrl', function($scope, api) {
  $scope.runners = [];
  $scope.loading = false;

  $scope.searchRunner = function(query) {
    $scope.loading = true;
    api.getRunners(query).success(function(data, status, headers, config) {
      $scope.loading = false;
      $scope.runners = data;
    }).error(function(data, status, headers, config) {
      $scope.loading = false;
      console.log('error');
    });
  }

});

app.controller('RunnerCtrl', function($scope, $stateParams, api) {
  var runnerId = $stateParams.id,
    editMode = $stateParams.editMode;
  console.log(runnerId, editMode);

});
