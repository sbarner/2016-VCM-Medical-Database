// load libraries
var express = require('express');
var mysql = require('mysql');
var _ = require('underscore');

// instantiate express object
var server = express();

// serve everything in public
server.use(express.static('public'));

// api
server.get('/api/runners', function(req, res) {
  var query = req.query.q || "";

  res.send([{id:2, firstName:'bob', lastName:'test'}]);
});

// listen on port 8080
server.listen(8080);
